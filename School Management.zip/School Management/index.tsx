'use client'

import Image from 'next/image'
import { useState, useEffect } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { BarChart3, BookOpen, Calendar, FileText, ImageIcon, Users2, GraduationCap, ClipboardList } from 'lucide-react'

const dashboardItems = [
  { icon: FileText, title: "নোটিশ", color: "bg-gradient-to-br from-orange-400 to-orange-100" },
  { icon: Users2, title: "শিক্ষার্থী ব্যবস্থাপনা", color: "bg-gradient-to-br from-blue-400 to-blue-100" },
  { icon: BarChart3, title: "পরিসংখ্যান", color: "bg-gradient-to-br from-purple-400 to-purple-100" },
  { icon: Calendar, title: "একাডেমিক ক্যালেন্ডার", color: "bg-gradient-to-br from-green-400 to-green-100" },
  { icon: BookOpen, title: "ক্লাস কার্যক্রম", color: "bg-gradient-to-br from-red-400 to-red-100" },
  { icon: ImageIcon, title: "ফটো গ্যালারি", color: "bg-gradient-to-br from-yellow-400 to-yellow-100" },
  { icon: GraduationCap, title: "পরীক্ষার ফলাফল", color: "bg-gradient-to-br from-emerald-400 to-emerald-100" },
  { icon: ClipboardList, title: "পিটিপি", color: "bg-gradient-to-br from-cyan-400 to-cyan-100" }
]

export default function Home() {
  const [mounted, setMounted] = useState(false)

  useEffect(() => {
    setMounted(true)
  }, [])

  return (
    <div className="min-h-screen bg-gradient-to-b from-[#f0f4f8] to-[#d9e2ec]">
      {/* Header */}
      <header className="relative bg-gradient-to-r from-[#1a365d] to-[#2d4a8a] py-16">
        <div className="container mx-auto px-4">
          <div className="relative w-full max-w-5xl mx-auto aspect-[4/3] rounded-2xl overflow-hidden shadow-2xl mb-8 transform hover:scale-[1.02] transition-transform duration-300">
            <Image 
              src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/_e62ae350-7340-417d-b5f1-2439e8082339-qvVQ8zMIFLqAuKhLz014xNNI1D8APg.jpeg"
              alt="SSC 26 Batch"
              fill
              className="object-cover"
              priority
            />
            <div className="absolute inset-0 bg-black bg-opacity-30 transition-opacity duration-300 hover:bg-opacity-0"></div>
          </div>
          <motion.div 
            className="text-center mt-8"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.2 }}
          >
            <h1 className="text-5xl font-bold text-white mb-2 text-shadow-lg">
              নওয়াপাড়া শংকরপাশা সরকারি মাধ্যমিক বিদ্যালয়
            </h1>
          </motion.div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container mx-auto px-4 py-16">
        <AnimatePresence>
          {mounted && (
            <motion.div 
              className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8"
              initial="hidden"
              animate="visible"
              variants={{
                hidden: { opacity: 0 },
                visible: {
                  opacity: 1,
                  transition: {
                    delayChildren: 0.3,
                    staggerChildren: 0.2
                  }
                }
              }}
            >
              {dashboardItems.map((item, index) => (
                <motion.div
                  key={index}
                  whileHover={{ scale: 1.05, rotate: 1 }}
                  whileTap={{ scale: 0.95 }}
                  variants={{
                    hidden: { y: 20, opacity: 0 },
                    visible: {
                      y: 0,
                      opacity: 1
                    }
                  }}
                >
                  <div className={`${item.color} rounded-xl overflow-hidden shadow-lg hover:shadow-2xl transition-all duration-300`}>
                    <div className="p-6 flex flex-col items-center justify-center text-center space-y-4">
                      <motion.div 
                        className="p-4 rounded-full bg-white shadow-inner"
                        whileHover={{ rotate: 360 }}
                        transition={{ duration: 0.5 }}
                      >
                        <item.icon className="h-10 w-10 text-[#1a365d]" />
                      </motion.div>
                      <h2 className="text-lg font-semibold text-[#1a365d]">
                        {item.title}
                      </h2>
                    </div>
                  </div>
                </motion.div>
              ))}
            </motion.div>
          )}
        </AnimatePresence>
      </main>
    </div>
  )
}