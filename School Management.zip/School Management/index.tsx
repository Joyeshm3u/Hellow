'use client'

import { useState } from 'react'
import { motion } from 'framer-motion'

const navItems = [
  { name: "প্রথম পাতা", color: "text-[#1a365d]" },
  { name: "কার্যক্রম বিবরণ", color: "text-[#2d4a8a]" },
  { name: "পাঠ্যক্রম", color: "text-[#1a365d]" },
  { name: "একাডেমিক তথ্য", color: "text-[#2d4a8a]" },
  { name: "ছাত্রছাত্রী", color: "text-[#1a365d]" },
  { name: "পিটিপি", color: "text-[#2d4a8a]" },
  { name: "গ্যালারি", color: "text-[#1a365d]" }
]

export default function Navigation() {
  const [activeItem, setActiveItem] = useState(0)

  return (
    <nav className="sticky top-0 z-50 bg-white border-b shadow-sm">
      <div className="container mx-auto px-4">
        <ul className="flex space-x-6 overflow-x-auto py-4 text-sm">
          {navItems.map((item, index) => (
            <li key={item.name} className="relative">
              <button
                onClick={() => setActiveItem(index)}
                className={`${item.color} hover:text-[#f97316] transition-colors duration-200 font-medium focus:outline-none`}
              >
                {item.name}
              </button>
              {activeItem === index && (
                <motion.div
                  className="absolute bottom-0 left-0 right-0 h-0.5 bg-[#f97316]"
                  layoutId="underline"
                />
              )}
            </li>
          ))}
        </ul>
      </div>
    </nav>
  )
}