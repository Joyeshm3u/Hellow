import Header from '@/components/Header'
import Navigation from '@/components/Navigation'
import Dashboard from '@/components/Dashboard'

export default function Home() {
  return (
    <div className="min-h-screen bg-gradient-to-b from-[#f8f9fa] to-[#e9ecef]">
      <Header />
      <Navigation />
      <Dashboard />
    </div>
  )
}