import Image from 'next/image'

export default function Header() {
  return (
    <header className="relative bg-gradient-to-b from-[#1a365d] to-[#2d4a8a] py-12">
      <div className="container mx-auto px-4">
        <div className="relative w-full max-w-5xl mx-auto aspect-[4/3] rounded-lg overflow-hidden shadow-2xl mb-8 transform hover:scale-[1.02] transition-transform duration-300">
          <Image 
            src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/_e62ae350-7340-417d-b5f1-2439e8082339-qvVQ8zMIFLqAuKhLz014xNNI1D8APg.jpeg"
            alt="SSC 26 Batch"
            fill
            className="object-cover"
            priority
          />
        </div>
        <div className="text-center mt-6">
          <h1 className="text-4xl font-bold text-white mb-2">নওয়াপাড়া শংকরপাশা সরকারি মাধ্যমিক বিদ্যালয়</h1>
          <p className="text-xl text-[#f8f9fa] opacity-90">শিক্ষা, সংস্কৃতি এবং উন্নয়নের পথে</p>
        </div>
      </div>
    </header>
  )
}