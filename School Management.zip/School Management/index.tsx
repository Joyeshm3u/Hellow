import '@/styles/globals.css'
import { Inter } from 'next/font/google'

const inter = Inter({ subsets: ['latin'] })

export const metadata = {
  title: 'নওয়াপাড়া শংকরপাশা সরকারি মাধ্যমিক বিদ্যালয়',
  description: 'শিক্ষা, সংস্কৃতি এবং উন্নয়নের পথে',
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="bn">
      <body className={inter.className}>{children}</body>
    </html>
  )
}